__author__ = 'Georg Richter'
__version__ = '1.1.5.post3'
__version_info__ = (1, 1, 5, 'post', '3')
